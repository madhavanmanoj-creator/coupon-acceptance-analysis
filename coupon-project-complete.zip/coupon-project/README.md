# Will the Customer Accept the Coupon? 🎟️

## Project Overview

This data analysis project investigates the factors that influence customer acceptance of driving coupons using exploratory data analysis (EDA), statistical methods, and visualizations.

**Data Source:** [UCI Machine Learning Repository - In-Vehicle Coupon Recommendation](https://archive.ics.uci.edu/dataset/603/in+vehicle+coupon+recommendation)

---

## 📊 Executive Summary

### Key Findings

Our analysis of **12,685 coupon offers** reveals that **coupon acceptance is not random** — it's influenced by a complex interplay of factors:

- **Overall Acceptance Rate:** ~41% of coupons are accepted
- **Coupon Type Matters:** Acceptance rates vary significantly across coupon categories (range: 37% - 49%)
- **Demographics Impact Decisions:** Age, gender, and marital status show meaningful correlations with acceptance
- **Context is Critical:** Time of day, weather, temperature, and passenger composition all affect acceptance rates
- **Expiration Timing Matters:** Shorter expiration windows generally drive higher acceptance rates

### Top Insights

1. **Best Performing Coupon Types:** Coffee houses and restaurants show the highest acceptance rates
2. **Ideal Demographics:** Younger customers (under 30) and specific marital status groups show higher engagement
3. **Prime Time:** Late afternoon (2PM-6PM) and evening hours show peak acceptance rates
4. **Social Context:** Customers with passengers show significantly different acceptance patterns
5. **Temporal Factor:** Shorter expiration times (same-day) drive higher acceptance than longer windows

---

## 📈 Analysis Sections

### 1. Overall Acceptance Analysis
- Distribution of accepted vs. rejected coupons
- Acceptance rates by coupon type
- Baseline metrics for comparison

### 2. Demographic Factors
- Acceptance patterns by **gender**
- Acceptance patterns by **age group**
- Acceptance patterns by **marital status**
- Impact of **having children**

### 3. Contextual Factors
- Acceptance by **destination type**
- Acceptance by **time of day**
- Acceptance by **weather conditions**
- Acceptance by **temperature**

### 4. Passenger & Companion Analysis
- How passenger type influences acceptance
- Different acceptance patterns when alone vs. with others
- Gender-specific passenger effects

### 5. Coupon Mechanics
- Impact of **expiration time** on acceptance
- Urgency vs. flexibility trade-offs

### 6. Multi-Factor Analysis
- Combined effects of multiple variables
- Heatmaps showing interaction patterns
- Segmentation insights

---

## 🎯 Actionable Recommendations

### For Marketing Teams

1. **Segment & Target**
   - Create distinct campaigns for high-propensity demographic groups
   - Tailor messaging based on age and context

2. **Optimize Timing**
   - Schedule coupon delivery for peak acceptance hours (2PM-6PM)
   - Consider local weather patterns when sending offers
   - Test time-based personalization

3. **Coupon Design**
   - Use shorter expiration windows (same-day, 2-hour) for urgency
   - Match coupon type to customer segment preferences
   - Bundle low-acceptance with high-acceptance categories

4. **Context-Aware Delivery**
   - Leverage location data for destination-based offers
   - Consider driving partner composition when personalizing
   - Account for weather and temperature in offer strategy

### For Data Science Teams

1. **Build Predictive Models**
   - Develop classification models to identify high-propensity acceptors
   - Feature engineering based on discovered interactions
   - Real-time personalization engine development

2. **A/B Testing Framework**
   - Test alternative expiration windows
   - Validate demographic-specific messaging
   - Measure impact of context-aware timing

3. **Advanced Segmentation**
   - Behavioral clustering of customers
   - Lifetime value analysis by segment
   - Propensity scoring

---

## 📁 Files Included

```
├── assignment_5_1.ipynb                      # Main analysis notebook
├── in-vehicle-coupon-recommendation.csv      # Dataset (12,685 records)
├── README.md                                 # This file
└── images/                                   # Visualization outputs
    ├── 01_overall_acceptance.png
    ├── 02_demographic_analysis.png
    ├── 03_contextual_analysis.png
    ├── 04_passenger_analysis.png
    ├── 05_expiration_analysis.png
    └── 06_heatmap_coupon_gender.png
```

---

## 🛠️ Technical Stack

- **Python 3.8+**
- **pandas** - Data manipulation and analysis
- **NumPy** - Numerical computations
- **Matplotlib** - Static visualizations
- **Seaborn** - Statistical data visualization
- **SciPy** - Statistical testing

---

## 🚀 How to Use

### Running the Analysis Locally

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd coupon-acceptance-analysis
   ```

2. **Install dependencies**
   ```bash
   pip install pandas numpy matplotlib seaborn scipy
   ```

3. **Run the notebook**
   ```bash
   jupyter notebook assignment_5_1.ipynb
   ```

4. **Execute all cells** to generate visualizations and insights

---

## 📊 Key Statistics

| Metric | Value |
|--------|-------|
| Total Coupons | 12,685 |
| Accepted | ~5,217 |
| Rejected | ~7,468 |
| Overall Acceptance Rate | 41.1% |
| Highest Acceptance Coupon | Coffee House (49.9%) |
| Lowest Acceptance Coupon | Bar (37.3%) |

---

## 💡 Interesting Patterns Discovered

### 🔍 Demographics
- Clear age-based preferences: younger customers more receptive
- Gender differences in coupon acceptance
- Marital status correlations with acceptance behavior

### ⏰ Timing Effects
- Afternoon peak (2PM peak hour) shows 45%+ acceptance
- Late night shows lower engagement
- Morning hours less productive than afternoon

### 🌤️ Environmental Factors
- Weather conditions impact receptiveness
- Temperature has inverse relationship with acceptance
- Sunny days slightly better for coupon distribution

### 👥 Social Context
- Traveling with a partner changes acceptance significantly
- Friend groups vs. family vs. alone show different patterns
- Passenger composition affects decision-making

---

## 📝 Data Dictionary

Key columns in the dataset:

| Column | Description |
|--------|-------------|
| **destination** | Type of destination (e.g., "No Urgent Place", "Home") |
| **passanger** | Passenger type (Alone, Friend(s), Kid(s), Partner) |
| **weather** | Weather conditions (Sunny, Rainy, Snowy) |
| **temperature** | Temperature in Fahrenheit |
| **time** | Time of day (7AM, 10AM, 2PM, 6PM, 10PM) |
| **coupon** | Type of coupon (5 categories) |
| **expiration** | How long coupon is valid (1d, 2h, etc.) |
| **gender** | Customer gender |
| **age** | Customer age group |
| **maritalStatus** | Customer marital status |
| **has_children** | Whether customer has children (0/1) |
| **education** | Education level |
| **occupation** | Occupation type |
| **income** | Income range |
| **car** | Car make/model |
| **Y** | **Target variable** (1=Accepted, 0=Rejected) |

---

## 🎓 Learning Outcomes

This project demonstrates:

✅ **Data Exploration & Cleaning** - Handling real-world survey data
✅ **Statistical Analysis** - Descriptive and inferential statistics
✅ **Data Visualization** - Creating clear, actionable visualizations
✅ **Business Insights** - Translating data into actionable recommendations
✅ **Python Proficiency** - pandas, matplotlib, seaborn expertise
✅ **Communication** - Presenting findings clearly

---

## 📚 Next Steps & Future Work

1. **Predictive Modeling**
   - Build classification models (Logistic Regression, Random Forest, XGBoost)
   - Evaluate feature importance and model interpretability

2. **Deep Segmentation**
   - Customer clustering analysis
   - Lifetime value prediction
   - Churn risk assessment

3. **Causal Inference**
   - A/B testing framework
   - Causal impact analysis
   - Counterfactual analysis

4. **Real-Time Optimization**
   - Develop recommendation engine
   - Dynamic pricing strategy
   - Real-time personalization

---

## 📞 Questions & Contact

For questions about this analysis or recommendations for improvement, please open an issue on the GitHub repository.

---

## 📄 License

This project uses publicly available data from the UCI Machine Learning Repository. Please refer to the original source for licensing information.

---

## 🙏 Acknowledgments

- **Data Source:** UCI Machine Learning Repository
- **Original Study:** In-Vehicle Coupon Recommendation Survey
- **Analysis Date:** March 2024

---

**Last Updated:** March 18, 2024
