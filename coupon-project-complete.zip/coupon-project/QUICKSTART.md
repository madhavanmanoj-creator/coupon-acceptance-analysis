# 🚀 Coupon Acceptance Analysis - Quick Start Guide

Welcome! This guide will help you set up and run the coupon acceptance analysis project in under 5 minutes.

## 📦 What's Included

- **assignment_5_1.ipynb** - Complete Jupyter notebook with analysis and visualizations
- **in-vehicle-coupon-recommendation.csv** - Dataset with 12,685 records
- **images/** - 6 professional visualization PNG files (already generated)
- **README.md** - Non-technical project summary with findings
- **requirements.txt** - Python dependencies
- **.gitignore** - Git configuration file

## ⚡ Quick Setup (5 minutes)

### Step 1: Extract the ZIP File
```bash
# On Windows: Right-click → Extract All
# On Mac/Linux:
unzip coupon-acceptance-analysis.zip
cd coupon-acceptance-analysis
```

### Step 2: Install Python Dependencies
```bash
pip install -r requirements.txt
```

**Required:**
- Python 3.7+
- pip (Python package manager)

**Dependencies installed:**
- pandas - Data manipulation
- numpy - Numerical computing
- matplotlib - Plotting
- seaborn - Statistical visualization
- scipy - Scientific computing
- jupyter - Interactive notebooks
- ipython - Enhanced Python shell

### Step 3: View the Analysis

#### Option A: Open Jupyter Notebook (Recommended)
```bash
jupyter notebook assignment_5_1.ipynb
```
This will open an interactive notebook in your browser where you can:
- See all analysis code and outputs
- View data exploration results
- Examine statistical findings
- Explore visualizations

#### Option B: View Generated Visualizations
All visualizations are pre-generated in the `images/` folder:
- `01_overall_acceptance.png` - Overall acceptance rates
- `02_demographic_analysis.png` - Analysis by gender, age, marital status
- `03_contextual_analysis.png` - Analysis by destination, time, weather
- `04_passenger_analysis.png` - Acceptance by passenger type
- `05_expiration_analysis.png` - Acceptance by coupon expiration
- `06_heatmap_coupon_gender.png` - Coupon type vs gender heatmap

#### Option C: Read the Summary
Open `README.md` for a non-technical overview of findings and recommendations.

---

## 📊 Project Overview

**Dataset:** In-Vehicle Coupon Recommendation System (UCI ML Repository)
- **Records:** 12,685 customer transactions
- **Features:** 26 variables including demographics, context, and acceptance outcome

**Key Finding:** 56.84% of customers accepted coupons

### Top Insights:
- **Best Coupon:** Carry out & Take away (73.55% acceptance)
- **Best Time:** 2PM (66.15% acceptance)
- **Best Passenger Type:** Friend(s) (67.34% acceptance)
- **Best Age Group:** Below 21 years (63.44% acceptance)
- **Best Expiration:** 1 day (62.56% acceptance)

---

## 🔄 Push to GitHub (Optional)

Want to showcase this on GitHub? Follow these steps:

### Step 1: Initialize Git
```bash
git init
git add .
git commit -m "Initial commit: Coupon acceptance analysis project"
git branch -M main
```

### Step 2: Add Remote & Push
```bash
git remote add origin https://github.com/YOUR_USERNAME/coupon-acceptance-analysis.git
git push -u origin main
```

**Note:** Replace `YOUR_USERNAME` with your GitHub username, and the repo must already exist on GitHub.

### Authentication Tips:
- Use Personal Access Token (PAT) instead of password
- Generate at: GitHub.com → Settings → Developer settings → Tokens (classic)
- Scope: Check ✅ `repo`

---

## 🛠️ Troubleshooting

### "jupyter: command not found"
```bash
pip install jupyter
```

### "ModuleNotFoundError: No module named 'pandas'"
```bash
pip install -r requirements.txt
```

### "Permission denied" on Mac/Linux
```bash
chmod +x installation
```

### Port 8888 already in use (Jupyter)
```bash
jupyter notebook --port 8889 assignment_5_1.ipynb
```

---

## 📚 Project Structure

```
coupon-acceptance-analysis/
├── assignment_5_1.ipynb              # Main analysis notebook
├── in-vehicle-coupon-recommendation.csv  # Dataset
├── README.md                          # Project overview
├── SETUP_GUIDE.md                     # Detailed setup instructions
├── QUICKSTART.md                      # This file
├── requirements.txt                   # Python dependencies
├── .gitignore                         # Git ignore patterns
└── images/                            # Pre-generated visualizations
    ├── 01_overall_acceptance.png
    ├── 02_demographic_analysis.png
    ├── 03_contextual_analysis.png
    ├── 04_passenger_analysis.png
    ├── 05_expiration_analysis.png
    └── 06_heatmap_coupon_gender.png
```

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] ZIP file extracted successfully
- [ ] `requirements.txt` installed with no errors
- [ ] Can open `assignment_5_1.ipynb` in Jupyter
- [ ] All 6 PNG images visible in `images/` folder
- [ ] Can read `README.md` in text editor
- [ ] (Optional) Successfully pushed to GitHub

---

## 📧 Next Steps

1. **Explore the analysis** - Open the notebook and interact with the data
2. **Review findings** - Check README.md for key insights
3. **Share your work** - Push to GitHub for your portfolio
4. **Customize** - Modify the analysis or add new visualizations

---

## 📝 Questions?

Refer to:
- **SETUP_GUIDE.md** - Detailed troubleshooting and setup
- **README.md** - Non-technical project summary
- **GITHUB_CHECKLIST.md** - GitHub-specific guidance

---

**Happy analyzing! 🎉**
