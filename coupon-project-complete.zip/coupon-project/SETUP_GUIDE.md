# GitHub Setup Guide - Coupon Acceptance Analysis

Follow these step-by-step instructions to create and push your repository to GitHub.

## Step 1: Create a New Repository on GitHub

1. Go to [GitHub.com](https://github.com) and sign in
2. Click the **"+"** icon in the top-right corner
3. Select **"New repository"**
4. Fill in the following details:

   | Field | Value |
   |-------|-------|
   | **Repository name** | `coupon-acceptance-analysis` |
   | **Description** | "Data analysis project examining customer coupon acceptance patterns" |
   | **Public/Private** | Public (for portfolio) |
   | **.gitignore** | Python (or skip - we have one) |
   | **Add README** | No (we already have one) |
   | **License** | MIT (optional) |

5. Click **"Create repository"**

6. **Copy the repository URL** - You'll see something like:
   ```
   https://github.com/YOUR_USERNAME/coupon-acceptance-analysis.git
   ```
   Keep this handy!

---

## Step 2: Initialize Local Repository

Open your terminal/command prompt and navigate to your project folder:

```bash
# Navigate to where your files are
cd /path/to/your/coupon-acceptance-analysis/

# Initialize git
git init

# Add your files
git add .

# Create first commit
git commit -m "Initial commit: Coupon acceptance analysis project

- Added Jupyter notebook with comprehensive EDA
- Included dataset and documentation
- Added README with findings and recommendations"

# Rename branch to main (if needed)
git branch -M main
```

---

## Step 3: Connect to GitHub and Push

Replace `YOUR_USERNAME` with your GitHub username:

```bash
# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/coupon-acceptance-analysis.git

# Push to GitHub
git push -u origin main
```

---

## Step 4: Verify Your Repository

1. Go to `https://github.com/YOUR_USERNAME/coupon-acceptance-analysis`
2. Check that all files are visible:
   - ✅ README.md
   - ✅ assignment_5_1.ipynb
   - ✅ in-vehicle-coupon-recommendation.csv
   - ✅ .gitignore
   - ✅ SETUP_GUIDE.md

3. Verify the README displays correctly (it should show your analysis summary)

---

## Step 5: Generate Images (Optional but Recommended)

The notebook includes code to save visualizations. When you run the notebook:

```bash
jupyter notebook assignment_5_1.ipynb
```

The notebook will create visualization files in an `images/` folder. Add these:

```bash
# Create images folder if needed
mkdir -p images

# Run all notebook cells to generate images

# Add images to git
git add images/
git commit -m "Add visualization outputs"
git push origin main
```

---

## Troubleshooting

### "fatal: not a git repository"
Run `git init` first to initialize the repository

### "fatal: remote origin already exists"
If you already added the remote, use:
```bash
git remote set-url origin https://github.com/YOUR_USERNAME/coupon-acceptance-analysis.git
```

### Authentication Issues
If you get auth errors, use GitHub CLI:
```bash
# Install GitHub CLI from https://cli.github.com
# Then authenticate
gh auth login

# Push using gh
gh repo create coupon-acceptance-analysis --public --source=. --remote=origin --push
```

---

## Your GitHub Repository URL

Once pushed, your repository will be at:

```
https://github.com/YOUR_USERNAME/coupon-acceptance-analysis
```

Share this link in your portfolio, resume, or job applications!

---

## Tips for Portfolio Success

✅ Add a descriptive commit message
✅ Keep the README updated with new findings
✅ Include visualization images in the repo
✅ Add a requirements.txt for dependencies:

```bash
pip freeze > requirements.txt
git add requirements.txt
git commit -m "Add requirements.txt"
git push
```

✅ Consider pinning the repo on your GitHub profile
✅ Link to this repo from your portfolio website

---

## Next Steps

- Run the notebook and generate visualizations
- Push the images folder to GitHub
- Add the repository link to your resume/portfolio
- Consider creating a GitHub Pages site with your findings

---

**Questions?** Refer back to this guide or check GitHub's official documentation at [docs.github.com](https://docs.github.com)
